<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$errors = [];
$message = '';

/**
 * Har cart action ke baad cart.php par wapas aayen.
 */
function cartRedirect(): never
{
    header('Location: cart.php');
    exit;
}

/**
 * Product ke liye valid size check karein.
 */
function cartValidSize(string $size, string $category): bool
{
    if (strtolower(trim($category)) === 'accessories') {
        return $size === 'One Size';
    }

    return in_array($size, ['S', 'M', 'L', 'XL'], true);
}

/**
 * POST actions: add, update, remove, clear.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $action = (string) ($_POST['action'] ?? '');

    try {
        if ($action === 'add') {
            $productId = filter_var(
                $_POST['product_id'] ?? null,
                FILTER_VALIDATE_INT
            );

            $quantity = filter_var(
                $_POST['quantity'] ?? 1,
                FILTER_VALIDATE_INT
            );

            $size = trim((string) ($_POST['size'] ?? ''));

            if (
                $productId === false || $productId === null ||
                $productId < 1 || $quantity === false ||
                $quantity === null || $quantity < 1 || $quantity > 99
            ) {
                throw new RuntimeException('Product ya quantity valid nahi hai.');
            }

            $stmt = $conn->prepare(
                'SELECT Id, Name, category, stock, price
                 FROM products
                 WHERE Id = ?'
            );

            $stmt->bind_param('i', $productId);
            $stmt->execute();
            $product = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$product) {
                throw new RuntimeException('Yeh product available nahi hai.');
            }

            if (!cartValidSize($size, (string) $product['category'])) {
                throw new RuntimeException('Please product ka valid size select karein.');
            }

            if (!is_numeric($product['price']) || (float) $product['price'] < 0) {
                throw new RuntimeException('Product ki price database mein valid nahi hai.');
            }

            $stock = (int) $product['stock'];
            $cartKey = $productId . '_' . $size;

            $existingQuantity = (int) (
                $_SESSION['cart'][$cartKey]['quantity'] ?? 0
            );

            if ($existingQuantity + $quantity > $stock) {
                throw new RuntimeException(
                    'Available stock sirf ' . $stock . ' hai.'
                );
            }

            $_SESSION['cart'][$cartKey] = [
                'product_id' => (int) $productId,
                'size' => $size,
                'quantity' => $existingQuantity + $quantity,
            ];

            $_SESSION['cart_message'] = 'Product successfully cart mein add ho gaya.';
            cartRedirect();
        }

        if ($action === 'update') {
            $cartKey = (string) ($_POST['cart_key'] ?? '');
            $quantity = filter_var(
                $_POST['quantity'] ?? null,
                FILTER_VALIDATE_INT
            );

            if (
                !isset($_SESSION['cart'][$cartKey]) ||
                !is_array($_SESSION['cart'][$cartKey])
            ) {
                throw new RuntimeException('Cart item nahi mila.');
            }

            if ($quantity === false || $quantity === null || $quantity < 1 || $quantity > 99) {
                throw new RuntimeException('Quantity 1 se 99 ke darmiyan honi chahiye.');
            }

            $productId = (int) $_SESSION['cart'][$cartKey]['product_id'];

            $stmt = $conn->prepare(
                'SELECT stock FROM products WHERE Id = ?'
            );
            $stmt->bind_param('i', $productId);
            $stmt->execute();
            $product = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$product) {
                unset($_SESSION['cart'][$cartKey]);
                throw new RuntimeException('Product ab available nahi hai; cart se remove kar diya gaya.');
            }

            if ($quantity > (int) $product['stock']) {
                throw new RuntimeException(
                    'Is product ka available stock ' .
                    (int) $product['stock'] . ' hai.'
                );
            }

            $_SESSION['cart'][$cartKey]['quantity'] = (int) $quantity;
            $_SESSION['cart_message'] = 'Cart update ho gaya.';
            cartRedirect();
        }

        if ($action === 'remove') {
            $cartKey = (string) ($_POST['cart_key'] ?? '');

            unset($_SESSION['cart'][$cartKey]);

            $_SESSION['cart_message'] = 'Product cart se remove ho gaya.';
            cartRedirect();
        }

        if ($action === 'clear') {
            $_SESSION['cart'] = [];
            $_SESSION['cart_message'] = 'Cart clear ho gaya.';
            cartRedirect();
        }

        throw new RuntimeException('Invalid cart action.');
    } catch (RuntimeException $e) {
        $errors[] = $e->getMessage();
    } catch (Throwable $e) {
        error_log('NEXORA cart error: ' . $e->getMessage());
        $errors[] = 'Cart update nahi ho saka. Dobara try karein.';
    }
}

if (!empty($_SESSION['cart_message'])) {
    $message = (string) $_SESSION['cart_message'];
    unset($_SESSION['cart_message']);
}

/**
 * Current cart ke products database se read karein.
 */
$items = [];
$grandTotal = 0.0;

if ($_SESSION['cart']) {
     $stmt = $conn->prepare(
    'SELECT Id, Name, price, image_url, stock
     FROM products
     WHERE Id = ?'
     );
    
    foreach ($_SESSION['cart'] as $cartKey => $cartItem) {
        if (!is_array($cartItem)) {
            unset($_SESSION['cart'][$cartKey]);
            continue;
        }

        $productId = filter_var(
            $cartItem['product_id'] ?? null,
            FILTER_VALIDATE_INT
        );

        $quantity = filter_var(
            $cartItem['quantity'] ?? null,
            FILTER_VALIDATE_INT
        );

        $size = trim((string) ($cartItem['size'] ?? ''));

        if (
            $productId === false || $productId === null ||
            $quantity === false || $quantity === null ||
            $productId < 1 || $quantity < 1 || $size === ''
        ) {
            unset($_SESSION['cart'][$cartKey]);
            continue;
        }

        $stmt->bind_param('i', $productId);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();

        if (!$product) {
            unset($_SESSION['cart'][$cartKey]);
            continue;
        }

        if (!is_numeric($product['price']) || (float) $product['price'] < 0) {
            $errors[] = 'Product "' . h($product['Name']) . '" ki price database mein valid nahi hai.';
            continue;
        }

        $price = (float) $product['price'];
        $stock = (int) $product['stock'];
        $lineTotal = $price * (int) $quantity;

        $items[] = [
            'cart_key' => (string) $cartKey,
            'product_id' => (int) $product['Id'],
            'name' => (string) $product['Name'],
            'price' => $price,
            'image_url' => (string) ($product['image_url'] ?? ''),
            'quantity' => (int) $quantity,
            'size' => $size,
            'stock' => $stock,
            'line_total' => $lineTotal,
        ];

        $grandTotal += $lineTotal;
    }

    $stmt->close();
}

$isLoggedIn = !empty($_SESSION['user_id']) || !empty($_SESSION['user']['Id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Shopping Cart | NEXORA FASHION</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f5f5f5;
            color: #171717;
            font-family: Arial, sans-serif;
        }

        .site-header {
            background: #111;
            color: #fff;
        }

        .nav {
            width: min(1200px, 94%);
            min-height: 76px;
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
            padding: 16px 0;
        }

        .logo {
            color: #fff;
            text-decoration: none;
            font-size: 21px;
            font-weight: 800;
            letter-spacing: 2px;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 18px;
            flex-wrap: wrap;
        }

        .nav-links a {
            color: #fff;
            text-decoration: none;
            font-size: 14px;
        }

        .nav-links a:hover {
            color: #ccc;
        }

        .container {
            width: min(1200px, 94%);
            margin: 35px auto;
        }

        h1 {
            margin-bottom: 8px;
        }

        .muted {
            color: #666;
            font-size: 14px;
            line-height: 1.5;
        }

        .notice {
            background: #e8f8ed;
            color: #176b32;
            padding: 13px 16px;
            margin: 15px 0;
            border-radius: 7px;
        }

        .error {
            background: #fff0f0;
            color: #a00000;
            padding: 13px 16px;
            margin: 15px 0;
            border-radius: 7px;
        }

        .cart-layout {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 320px;
            gap: 25px;
            align-items: start;
        }

        .cart-items,
        .summary,
        .empty-cart {
            background: #fff;
            border-radius: 10px;
            padding: 22px;
            box-shadow: 0 4px 20px #00000008;
        }

        .cart-item {
            display: grid;
            grid-template-columns: 100px minmax(0, 1fr);
            gap: 18px;
            padding: 20px 0;
            border-bottom: 1px solid #eee;
        }

        .cart-item:first-child {
            padding-top: 0;
        }

        .product-image {
            width: 100px;
            height: 120px;
            object-fit: cover;
            background: #eee;
            border-radius: 6px;
        }

        .product-name {
            margin: 0 0 8px;
            font-size: 17px;
        }

        .item-price {
            font-weight: bold;
            margin: 10px 0;
        }

        .item-actions {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        input[type="number"] {
            width: 75px;
            padding: 9px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .btn {
            display: inline-block;
            border: 0;
            padding: 11px 15px;
            border-radius: 5px;
            background: #111;
            color: #fff;
            text-align: center;
            text-decoration: none;
            font-size: 14px;
            cursor: pointer;
        }

        .btn:hover {
            background: #333;
        }

        .btn-light {
            background: #eee;
            color: #111;
        }

        .btn-light:hover {
            background: #ddd;
        }

        .btn-danger {
            background: #a52323;
        }

        .btn-danger:hover {
            background: #801919;
        }

        .summary h2 {
            margin-top: 0;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            gap: 15px;
            padding: 12px 0;
            border-bottom: 1px solid #eee;
        }

        .summary-total {
            font-size: 20px;
            font-weight: bold;
        }

        .checkout-btn {
            display: block;
            width: 100%;
            margin-top: 20px;
            padding: 15px 20px;
            background: #111;
            color: #fff;
            text-align: center;
            text-decoration: none;
            font-weight: bold;
            border-radius: 6px;
            cursor: pointer;
        }

        .checkout-btn:hover {
            background: #333;
        }

        .summary .btn {
            display: block;
            width: 100%;
            margin-top: 12px;
        }

        .summary form {
            margin: 0;
        }

        footer {
            margin-top: 45px;
            padding: 25px;
            text-align: center;
            color: #777;
        }

        @media (max-width: 800px) {
            .cart-layout {
                grid-template-columns: 1fr;
            }

            .nav {
                justify-content: center;
            }

            .nav-links {
                justify-content: center;
            }
        }

        @media (max-width: 480px) {
            .cart-item {
                grid-template-columns: 75px minmax(0, 1fr);
                gap: 12px;
            }

            .product-image {
                width: 75px;
                height: 95px;
            }

            .cart-items,
            .summary,
            .empty-cart {
                padding: 16px;
            }
        }
    </style>
</head>

<body>

<header class="site-header">
    <nav class="nav">
        <a class="logo" href="index.php">NEXORA FASHION</a>

        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="products.php">Shop</a>
            <a href="cart.php">Cart (<?= count($items) ?>)</a>

            <?php if ($isLoggedIn): ?>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
        </div>
    </nav>
</header>

<main class="container">
    <h1>Your Shopping Cart</h1>
    <p class="muted">Apne selected products aur quantities check karein.</p>

    <?php if ($message !== ''): ?>
        <div class="notice"><?= h($message) ?></div>
    <?php endif; ?>

    <?php foreach ($errors as $error): ?>
        <div class="error"><?= h($error) ?></div>
    <?php endforeach; ?>

    <?php if ($items): ?>
        <div class="cart-layout">

            <section class="cart-items">
                <?php foreach ($items as $item): ?>
                    <article class="cart-item">
                        <?php
                        $image = trim($item['image_url']);
                        $imageIsSafe = preg_match('~^(https?://|assets/)~i', $image) === 1;
                        ?>

                        <?php if ($image !== '' && $imageIsSafe): ?>
                            <img
                                class="product-image"
                                src="<?= h($image) ?>"
                                alt="<?= h($item['name']) ?>"
                            >
                        <?php else: ?>
                            <div class="product-image"></div>
                        <?php endif; ?>

                        <div>
                            <h2 class="product-name"><?= h($item['name']) ?></h2>

                            <div class="muted">
                                Size: <?= h($item['size']) ?>
                            </div>

                            <div class="item-price">
                                <?= h(money($item['price'])) ?>
                            </div>

                            <div class="muted">
                                Available stock: <?= (int) $item['stock'] ?>
                            </div>

                            <div class="muted">
                                Subtotal: <?= h(money($item['line_total'])) ?>
                            </div>

                            <div class="item-actions">
                                <form method="POST" action="cart.php">
                                    <input
                                        type="hidden"
                                        name="csrf_token"
                                        value="<?= h(csrf_token()) ?>"
                                    >
                                    <input type="hidden" name="action" value="update">
                                    <input
                                        type="hidden"
                                        name="cart_key"
                                        value="<?= h($item['cart_key']) ?>"
                                    >

                                    <label class="muted" for="qty-<?= h($item['cart_key']) ?>">
                                        Quantity
                                    </label>

                                    <input
                                        id="qty-<?= h($item['cart_key']) ?>"
                                        type="number"
                                        name="quantity"
                                        min="1"
                                        max="<?= max(1, min(99, $item['stock'])) ?>"
                                        value="<?= (int) $item['quantity'] ?>"
                                        required
                                    >

                                    <button class="btn" type="submit">
                                        Update
                                    </button>
                                </form>

                                <form method="POST" action="cart.php">
                                    <input
                                        type="hidden"
                                        name="csrf_token"
                                        value="<?= h(csrf_token()) ?>"
                                    >
                                    <input type="hidden" name="action" value="remove">
                                    <input
                                        type="hidden"
                                        name="cart_key"
                                        value="<?= h($item['cart_key']) ?>"
                                    >

                                    <button class="btn btn-danger" type="submit">
                                        Remove
                                    </button>
                                </form>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </section>

            <aside class="summary">
                <h2>Order Summary</h2>

                <div class="summary-row">
                    <span>Items</span>
                    <span><?= count($items) ?></span>
                </div>

                <div class="summary-row summary-total">
                    <span>Total</span>
                    <span><?= h(money($grandTotal)) ?></span>
                </div>

                <p class="muted">
                    Delivery charges, if any, will need to be confirmed separately.
                </p>

                <a class="checkout-btn" href="checkout.php">
                    Proceed to Checkout
                </a>

                <a class="btn btn-light" href="products.php">
                    Continue Shopping
                </a>

                <form method="POST" action="cart.php"
                      onsubmit="return confirm('Kya aap poora cart clear karna chahte hain?');">
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= h(csrf_token()) ?>"
                    >
                    <input type="hidden" name="action" value="clear">

                    <button class="btn btn-danger" type="submit">
                        Clear Cart
                    </button>
                </form>
            </aside>

        </div>

    <?php else: ?>

        <section class="empty-cart">
            <h2>Aapka cart empty hai</h2>
            <p class="muted">
                Shop par jaa kar apne favourite products add karein.
            </p>
            <a class="btn" href="products.php">Start Shopping</a>
        </section>

    <?php endif; ?>
</main>

<footer>
    &copy; <?= date('Y') ?> NEXORA FASHION. All rights reserved.
</footer>

</body>
</html>
