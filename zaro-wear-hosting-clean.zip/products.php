<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/db.php';

if (!isset($conn) || !($conn instanceof mysqli)) {
    exit('Database connection error: check includes/db.php.');
}

$conn->set_charset('utf8mb4');

function h($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function money($amount): string {
    return 'Rs. ' . number_format((float)$amount, 0);
}

$search = trim((string)($_GET['q'] ?? ''));
$category = trim((string)($_GET['category'] ?? 'All'));
$sort = (string)($_GET['sort'] ?? 'newest');

$allowedCategories = ['All', 'Men', 'Women', 'Accessories'];

if (!in_array($category, $allowedCategories, true)) {
    $category = 'All';
}

$orderBy = match ($sort) {
    'price_low'  => 'price ASC',
    'price_high' => 'price DESC',
    'name'       => 'name ASC',
    default      => 'id DESC',
};


$sql = "SELECT Id, Name, price, image_url, description, category
        FROM products
        WHERE 1 = 1";

$types = '';
$params = [];

if ($search !== '') {
    $sql .= " AND (Name LIKE ? OR description LIKE ?)";
    $term = '%' . $search . '%';
    $types .= 'ss';
    $params[] = $term;
    $params[] = $term;
}

if ($category !== 'All') {
    $sql .= " AND category = ?";
    $types .= 's';
    $params[] = $category;
}

/* Sirf approved columns ko sorting ke liye use karein */
$allowedOrder = [
    'default' => 'Id DESC',
    'price_low' => 'price ASC',
    'price_high' => 'price DESC',
    'name' => 'Name ASC'
];

$orderKey = $_GET['sort'] ?? 'default';
$orderBy = $allowedOrder[$orderKey] ?? 'Id DESC';

$sql .= " ORDER BY " . $orderBy;

$stmt = $conn->prepare($sql);

if ($types !== '') {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$products = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop All Products | ZARO WEAR</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="announcement">DISCOVER YOUR EVERYDAY STYLE</div>

<header class="header">
    <a class="logo" href="index.php">ZARO WEAR</a>

    <nav class="nav">
        <a href="index.php">Home</a>
        <a href="products.php?category=Women">Women</a>
        <a href="products.php?category=Men">Men</a>
        <a href="products.php?category=Accessories">Accessories</a>
    </nav>

    <div class="header-actions">
        <a class="icon-btn" href="cart.php" aria-label="Shopping cart">♧</a>
        <a class="text-link" href="login.php">Login</a>
    </div>
</header>

<main class="section">
    <div class="section-heading">
        <div>
            <span class="eyebrow">THE ZARO WEAR EDIT</span>
            <h2>Shop all products<span>.</span></h2>
            <p class="section-description">
                Find the pieces that fit your style.
            </p>
        </div>
        <span class="product-total">
            <?= count($products) ?> PRODUCTS
        </span>
    </div>

    <form action="products.php" method="get" class="shop-toolbar">
        <div class="category-filters">
            <?php foreach ($allowedCategories as $item): ?>
                <button
                    class="filter-btn <?= $category === $item ? 'active' : '' ?>"
                    type="submit"
                    name="category"
                    value="<?= h($item) ?>"
                >
                    <?= h($item) ?>
                </button>
            <?php endforeach; ?>
        </div>

        <label class="sort-control">
            <span>Sort:</span>
            <select name="sort" onchange="this.form.submit()">
                <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>
                    Newest
                </option>
                <option value="price_low" <?= $sort === 'price_low' ? 'selected' : '' ?>>
                    Price: Low to High
                </option>
                <option value="price_high" <?= $sort === 'price_high' ? 'selected' : '' ?>>
                    Price: High to Low
                </option>
                <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>
                    Name: A to Z
                </option>
            </select>
        </label>

        <input type="hidden" name="q" value="<?= h($search) ?>">
    </form>

    <form action="products.php" method="get" class="search-bar">
        <label for="q">Search products</label>
        <input
            id="q"
            name="q"
            type="search"
            placeholder="Search clothing..."
            value="<?= h($search) ?>"
        >
        <input type="hidden" name="category" value="<?= h($category) ?>">
        <input type="hidden" name="sort" value="<?= h($sort) ?>">
        <button class="btn btn-dark" type="submit">Search</button>
        <?php if ($search !== ''): ?>
            <a class="text-link" href="products.php">Clear</a>
        <?php endif; ?>
    </form>

    
<?php if ($products): ?>
    <div class="product-grid">
        <?php foreach ($products as $product): ?>
            <?php
                $productId = (int)($product['Id'] ?? 0);
                $productName = (string)($product['Name'] ?? 'Product');
                $imageUrl = trim((string)($product['image_url'] ?? ''));
            ?>

            <article class="product-card">

                <?php if ($imageUrl !== ''): ?>
                    <a
                        class="product-image"
                        href="product.php?id=<?= $productId ?>"
                    >
                        <img
                            src="<?= h($imageUrl) ?>"
                            alt="<?= h($productName) ?>"
                            loading="lazy"
                            onerror="this.closest('.product-image').remove();"
                        >
                    </a>
                <?php endif; ?>

                <div class="product-info">
                    <span class="product-category">
                        <?= h($product['category'] ?? '') ?>
                    </span>

                    <h3 class="product-title">
                        <a href="product.php?id=<?= $productId ?>">
                            <?= h($productName) ?>
                        </a>
                    </h3>

                    <div class="product-price">
                        <?= money($product['price'] ?? 0) ?>
                    </div>

                    <div class="product-bottom">
                        <a
                            class="add-button"
                            href="product.php?id=<?= $productId ?>"
                        >VIEW PRODUCT ↗</a>
                    </div>
                </div>

            </article>
        <?php endforeach; ?>
                </div>
                <?php else: ?>
    <p class="empty-state">
        No products found. Try another search or category.
    </p>
<?php endif; ?>

</main>

<footer class="footer">
    <div class="footer-bottom">
        <span>&copy; <?= date('Y') ?> ZARO WEAR</span>
        <a href="index.php">HOME ↑</a>
    </div>
</footer>

</body>
</html>
